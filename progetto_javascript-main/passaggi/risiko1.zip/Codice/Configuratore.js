class Configuratore{
    constructor(){

    }
    
    static Configura(){
        //contiene scelta numero giocatori e specifiche per giocatore
    }

    static DistribuisciCarteTerritorio(){

    }
}