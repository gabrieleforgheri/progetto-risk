class Giocatore{
    constructor(nome, cognome, nickName, numeroArmateIniziali,numeroArmate, coloreArmate, sopravissuto){
        this.nome=nome;
        this.cognome=cognome;
        this.nickName=nickName;
        this.numeroArmateIniziali=numeroArmateIniziali;
        this.numeroArmate=numeroArmate;
        this.coloreArmate=coloreArmate;
        this.sopravissuto=sopravissuto;
        this.carteTerritori=new Array();
        this.territoriConquistati=new Array();
        
    }

}