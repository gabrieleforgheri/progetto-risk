

//aggiungere colore territorio
let continenti=[{
    
    nome: "oceania",
    numeroArmateSupplementari: 2,
    territori: [
        {
            nome:"indonesia",
            numeroArmate:0,
            confinaCon: [
                "siam","nuova guinea","australia occidentale"
            ],
            propretario:"nickNameX",
            colore:"#000000"
        },{
            nome:"nuova guindea",
            numeroArmate:0,
            confinaCon: [
                "australia orientale","indonesia","australia occidentale"
            ],
            propretario:"nickNameX",
            colore:"#000000"
        },{
            nome:"australia occidentale",
            numeroArmate:0,
            confinaCon: [
                "australia orientale","indonesia","nuova guindea"
            ],
            propretario:"nickNameX",
            colore:"#000000"
        },{
            nome:"australia orientale",
            numeroArmate:0,
            confinaCon: [
                "australia occidentale","nuova guindea"
            ],
            propretario:"nickNameX",
            colore:"#000000"
        }
    ],
},

{
    nome: "sud america",
    numeroArmateSupplementari: 2,
    territori:[
        {
            nome:"venezuela",
            numeroArmate:0,
            confinaCon: [
                "america centrale","brasile","peru"  
            ],
            propretario:"nickNameX",
            colore:"#000000"
        },{
            nome:"brasile",
            numeroArmate:0,
            confinaCon: [
                "africa del nord","peru","venezuela" 
            ],
            propretario:"nickNameX",
            colore:"#000000"
        },{
            nome:"peru",
            numeroArmate:0,
            confinaCon: [
                "venezuela","brasile","argentina"  
            ],
            propretario:"nickNameX",
            colore:"#000000"
        },{
            nome:"argentina",
            numeroArmate:0,
            confinaCon: [
                "brasile","peru"  
            ],
            propretario:"nickNameX",
            colore:"#000000"
        }]
},
{
    nome:"europa",
    numeroArmateSupplementari:3,
    territori:[
        {
            nome:"islanda",
            numeroArmate:0,
            confinaCon: [
                "groenlandia","scandinavia","gran bretagna"  
            ],
            propretario:"nickNameX",
            colore:"#000000"
        },{
            nome:"scandinavia",
            numeroArmate:0,
            confinaCon: [
                "islanda","gran bretagna","europa settentrionale","ucraina"  
            ],
            propretario:"nickNameX"
        },{
            nome:"gran bretagna",
            numeroArmate:0,
            confinaCon: [
                "islanda","scandinavia","europa settentrionale","europa occidentale"  
            ],
            propretario:"nickNameX"
        },{
            nome:"europa settentrionale",
            numeroArmate:0,
            confinaCon: [
                "scandinavia","gran bretagna","europa occidentale","ucraina","europa maridionale"  
            ],
            propretario:"nickNameX"
        },{
            nome:"europa occidentale",
            numeroArmate:0,
            confinaCon: [
                "africa del nord","gran bretagna","europa settentrionale","europa meridionale"  
            ],
            propretario:"nickNameX"
        },{
            nome:"europa meridionale",
            numeroArmate:0,
            confinaCon: [
                "europa occidentale","africa del nord","europa settentrionale","ucraina" ,"egitto","medio oriente"  
            ],
            propretario:"nickNameX"
        },{
            nome:"ucraina",
            numeroArmate:0,
            confinaCon: [
                "europa settentrionale","urali","europa meridionale","scandinavia" ,"medio oriente","afghanistan"  
            ],
            propretario:"nickNameX"
        }
    ]
},
{
    nome:"africa",
    numeroArmateSupplementari:3,
    territori:[
        {

            nome:"africa del nord",
            numeroArmate:0,
            confinaCon: [
                "europa occidentale","egitto","congo","europa meridionale" ,"egitto","africa orientale"  
            ],
            propretario:"nickNameX"
        },{
            nome:"egitto",
            numeroArmate:0,
            confinaCon: [
                "europa meridionale","africa del nord","africa orientale","medio oriente","congo"  
            ],
            propretario:"nickNameX"
        },{
            nome:"africa orientale",
            numeroArmate:0,
            confinaCon: [
                "congo","africa del nord","madagascar","egitto","africa del sud"  
            ],
            propretario:"nickNameX"
        },{
            nome:"congo",
            numeroArmate:0,
            confinaCon: [
                "africa del nord","africa orientale","africa del sud"  
            ],
            propretario:"nickNameX"
        },{
            nome:"madagascar",
            numeroArmate:0,
            confinaCon: [
                "africa orientale","africa del sud"
            ],
            propretario:"nickNameX"
        },{
            nome:"africa del sud",
            numeroArmate:0,
            confinaCon: [
                "congo","africa orientale","madagascar"
            ],
            propretario:"nickNameX"
        }
    ]
},
{
    nome:"nord america",
    numeroArmateSupplementari:3,
    territori:[{
            nome:"groenlandia",
            numeroArmate:0,
            confinaCon: [
                "islanda","quebec","ontario","territori del nord ovest"  
            ],
            propretario:"nickNameX"
        },{
            nome:"quebec",
            numeroArmate:0,
            confinaCon: [
                "groenlandia","ontario","stati uniti orientali"  
            ],
            propretario:"nickNameX"
        },{
            nome:"ontario",
            numeroArmate:0,
            confinaCon: [
                "quebec","alberta","territori del nord ovest","groenlandia"  
            ],
            propretario:"nickNameX"
        },{
            nome:"stati uniti occidentali",
            numeroArmate:0,
            confinaCon: [
                "ontario","alberta","stati uniti orientali","america centrale"  
            ],
            propretario:"nickNameX"
        },{
            nome:"america centrale",
            numeroArmate:0,
            confinaCon: [
                "venezuela","stati uniti occidentali","stati uniti orientali"
            ],
            propretario:"nickNameX"
        },{
            nome:"alberta",
            numeroArmate:0,
            confinaCon: [
                "ontario","territori del nord ovest","stati uniti orientali","alaska"  
            ],
            propretario:"nickNameX"
        },{
            nome:"territori del nord ovest",
            numeroArmate:0,
            confinaCon: [
                "ontario","groenlandia","alberta","alaska"  
            ],
            propretario:"nickNameX"
        },{
            nome:"alaska",
            numeroArmate:0,
            confinaCon: [
                "kamchatka","territori del nord ovest","alberta"
            ],
            propretario:"nickNameX"
        },{
            nome:"stati uniti orientali",
            numeroArmate:0,
            confinaCon: [
                "america centrale","ontario","stati uniti occidentali","quebec"  
            ],
            propretario:"nickNameX"
        }]
},
{
    nome:"asia",
    numeroArmateSupplementari:3,
        territori:[{
            nome:"kamchatka",
            numeroArmate:0,
            confinaCon: [
                "cita","giappone","jacuzia","alaska" ,"mongolia"  
            ],
            propretario:"nickNameX"
        },{
            nome:"jacuzia",
            numeroArmate:0,
            confinaCon: [
                "cita","siberia","kamchatka"
            ],
            propretario:"nickNameX"
        },{
            nome:"siberia",
            numeroArmate:0,
            confinaCon: [
                "cita","urali","jacuzia","cina","mongolia"  
            ],
            propretario:"nickNameX"
        },{
            nome:"urali",
            numeroArmate:0,
            confinaCon: [
                "afghanistan","ucraina","siberia","cina"
            ],
            propretario:"nickNameX"
        },{
            nome:"afghanistan",
            numeroArmate:0,
            confinaCon: [
                "ucraina","urali","medio oriente","cina"
            ],
            propretario:"nickNameX"
        },{
            nome:"medio oriente",
            numeroArmate:0,
            confinaCon: [
                "europa meridionale","ucraina","jacuzia","alaska" ,"egitto","mongolia"  
            ],
            propretario:"nickNameX"
        },{
            nome:"india",
            numeroArmate:0,
            confinaCon: [
                "medio oriente","cina","siam"
            ],
            propretario:"nickNameX"
        },{
            nome:"siam",
            numeroArmate:0,
            confinaCon: [
                "india","cina","indonesia"
            ],
            propretario:"nickNameX"
        },{
            nome:"giappone",
            numeroArmate:0,
            confinaCon: [
                "mongolia","kamchatka" 
            ],
            propretario:"nickNameX"
        },{
            nome:"cita",
            numeroArmate:0,
            confinaCon: [
                "siberia","kamchatka","jacuzia","mongolia"  
            ],
            propretario:"nickNameX"
        },{
            nome:"mongolia",
            numeroArmate:0,
            confinaCon: [
                "siberia","giappone","kamchatka","cina","mongolia"  
            ],
            propretario:"nickNameX"
        }]
}]


























var territori=[{
    nome:"cina",
    numeroArmate:0,
    confinaCon: [
        "mongolia","siberia","urali","afghanistan","medio oriente","india","siam"  
    ],
    
},{
    nome:"groenlandia",
    numeroArmate:0,
    confinaCon: [
        "islanda","quebec","ontario","territori del nord ovest"  
    ],
},{
    nome:"quebec",
    numeroArmate:0,
    confinaCon: [
        "groenlandia","ontario","stati uniti orientali"  
    ],
},{
    nome:"ontario",
    numeroArmate:0,
    confinaCon: [
        "quebec","alberta","territori del nord ovest","groenlandia"  
    ],
},{
    nome:"stati uniti occidentali",
    numeroArmate:0,
    confinaCon: [
        "ontario","alberta","stati uniti orientali","america centrale"  
    ],
},{
    nome:"america centrale",
    numeroArmate:0,
    confinaCon: [
        "venezuela","stati uniti occidentali","stati uniti orientali"
    ],
},{
    nome:"alberta",
    numeroArmate:0,
    confinaCon: [
        "ontario","territori del nord ovest","stati uniti orientali","alaska"  
    ],
},{
    nome:"territori del nord ovest",
    numeroArmate:0,
    confinaCon: [
        "ontario","groenlandia","alberta","alaska"  
    ],
},{
    nome:"alaska",
    numeroArmate:0,
    confinaCon: [
        "kamchatka","territori del nord ovest","alberta"
    ],
},{
    nome:"stati uniti orientali",
    numeroArmate:0,
    confinaCon: [
        "america centrale","ontario","stati uniti occidentali","quebec"  
    ],
},{
    nome:"venezuela",
    numeroArmate:0,
    confinaCon: [
        "america centrale","brasile","peru"  
    ],
},{
    nome:"brasile",
    numeroArmate:0,
    confinaCon: [
        "africa del nord","peru","venezuela" 
    ],
},{
    nome:"peru",
    numeroArmate:0,
    confinaCon: [
        "venezuela","brasile","argentina"  
    ],
},{
    nome:"argentina",
    numeroArmate:0,
    confinaCon: [
        "brasile","peru"  
    ],
},{
    nome:"islanda",
    numeroArmate:0,
    confinaCon: [
        "groenlandia","scandinavia","gran bretagna"  
    ],
},{
    nome:"scandinavia",
    numeroArmate:0,
    confinaCon: [
        "islanda","gran bretagna","europa settentrionale","ucraina"  
    ],
},{
    nome:"gran bretagna",
    numeroArmate:0,
    confinaCon: [
        "islanda","scandinavia","europa settentrionale","europa occidentale"  
    ],
},{
    nome:"europa settentrionale",
    numeroArmate:0,
    confinaCon: [
        "scandinavia","gran bretagna","europa occidentale","ucraina","europa maridionale"  
    ],
},{
    nome:"europa occidentale",
    numeroArmate:0,
    confinaCon: [
        "africa del nord","gran bretagna","europa settentrionale","europa meridionale"  
    ],
},{
    nome:"europa meridionale",
    numeroArmate:0,
    confinaCon: [
        "europa occidentale","africa del nord","europa settentrionale","ucraina" ,"egitto","medio oriente"  
    ],
},{
    nome:"ucraina",
    numeroArmate:0,
    confinaCon: [
        "europa settentrionale","urali","europa meridionale","scandinavia" ,"medio oriente","afghanistan"  
    ],
},{
    nome:"africa del nord",
    numeroArmate:0,
    confinaCon: [
        "europa occidentale","egitto","congo","europa meridionale" ,"egitto","africa orientale"  
    ],
},{
    nome:"egitto",
    numeroArmate:0,
    confinaCon: [
        "europa meridionale","africa del nord","africa orientale","medio oriente","congo"  
    ],
},{
    nome:"africa orientale",
    numeroArmate:0,
    confinaCon: [
        "congo","africa del nord","madagascar","egitto","africa del sud"  
    ],
},{
    nome:"congo",
    numeroArmate:0,
    confinaCon: [
        "africa del nord","africa orientale","africa del sud"  
    ],
},{
    nome:"madagascar",
    numeroArmate:0,
    confinaCon: [
        "africa orientale","africa del sud"
    ],
},{
    nome:"africa del sud",
    numeroArmate:0,
    confinaCon: [
        "congo","africa orientale","madagascar"
    ],
},{
    nome:"kamchatka",
    numeroArmate:0,
    confinaCon: [
        "cita","giappone","jacuzia","alaska" ,"mongolia"  
    ],
},{
    nome:"jacuzia",
    numeroArmate:0,
    confinaCon: [
        "cita","siberia","kamchatka"
    ],
},{
    nome:"siberia",
    numeroArmate:0,
    confinaCon: [
        "cita","urali","jacuzia","cina","mongolia"  
    ],
},{
    nome:"urali",
    numeroArmate:0,
    confinaCon: [
        "afghanistan","ucraina","siberia","cina"
    ],
},{
    nome:"afghanistan",
    numeroArmate:0,
    confinaCon: [
        "ucraina","urali","medio oriente","cina"
    ],
},{
    nome:"medio oriente",
    numeroArmate:0,
    confinaCon: [
        "europa meridionale","ucraina","jacuzia","alaska" ,"egitto","mongolia"  
    ],
},{
    nome:"india",
    numeroArmate:0,
    confinaCon: [
        "medio oriente","cina","siam"
    ],
},{
    nome:"siam",
    numeroArmate:0,
    confinaCon: [
        "india","cina","indonesia"
    ],
},{
    nome:"giappone",
    numeroArmate:0,
    confinaCon: [
        "mongolia","kamchatka" 
    ],
},{
    nome:"cita",
    numeroArmate:0,
    confinaCon: [
        "siberia","kamchatka","jacuzia","mongolia"  
    ],
},{
    nome:"mongolia",
    numeroArmate:0,
    confinaCon: [
        "siberia","giappone","kamchatka","cina","mongolia"  
    ],
},{
    nome:"indonesia",
    numeroArmate:0,
    confinaCon: [
        "siam","nuova guinea","australia occidentale"
    ],
},{
    nome:"nuova guindea",
    numeroArmate:0,
    confinaCon: [
        "australia orientale","indonesia","australia occidentale"
    ],
},{
    nome:"australia occidentale",
    numeroArmate:0,
    confinaCon: [
        "australia orientale","indonesia","nuova guindea"
    ],
},{
    nome:"australia orientale",
    numeroArmate:0,
    confinaCon: [
        "australia occidentale","nuova guindea"
    ],
}
]

