importScripts (["map.js","PartitaController.js","Utilities.js","Giocatore.js"]);

