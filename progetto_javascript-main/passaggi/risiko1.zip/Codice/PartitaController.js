importScripts("map.js");


class PartitaController{
    constructor(){
        this.numeroArmatePerGiocatore;
    }
    
    static IniziaPartita(){

    }
    static TerminaPartita(){

    }
    static EseguiPiazzamentoIniziale(){

    }
    
    static AggiornaNotifiche(messaggio){

    }

}
class Partita{
    constructor(stato,numeroGiocatori){
        this.stato=stato;
        this.numeroGiocatori=numeroGiocatori;
        this.giocatoreVincitore;
    }
    static Inizia(){

    }
    static Termina(){

    }
    static CambiaTurno(){

    }
}

class Turno{
    constructor(inizialeSN, numeroArmateRinforzo,numeroArmateSpostate){
        this.inizialeSN=inizialeSN;
        this.numeroArmateRinforzo=numeroArmateRinforzo;
        this.numeroArmateSpostate=numeroArmateSpostate;
    }
    CalcoloAramate(){

    }
}

class Attacco{
    constructor(stato, nickNameAttaccante,nickNameDifensore){
        this.stato=stato;
        this.nickNameAttaccante=nickNameAttaccante;
        this.nickNameDifensore=nickNameDifensore;            
    }
    static Esegui(targetAttanccante, targetDifensore, giocatore){
        /*
        
        AL POSTO DI NEIGHBOUR USARE "confinaCon"


        Gamestate.attack = function(e){
            this.countries.forEach(country => {
                if(e.target.id === country.name){
                    this.prevTarget = e.target;
                    if(this.prevCountry){
                        if(this.prevCountry.name !== country.name && this.prevCountry.owner !== country.owner && this.prevCountry.owner === this.player.name){
                            this.prevCountry.neighbours.forEach(neighbour => {               
                            if(neighbour === country.name && neighbour.owner !== country.name && this.prevCountry.numeroArmate > 0){       
                                return this.battle(this.prevCountry, country, this.player, 0);            
                            }                
                            })
                        }      
                    }
                    this.prevCountry = country;
                }
            });   
        } */
        
        //metodo senza usare la mappa clickabile
        continenti.forEach(elem=>{
            elem.territori.forEach(scelta=>{
                //controllo sui possessi
                if(scelta.nome==targetAttanccante && scelta.propretario==this.nickNameAttaccante)
                this.territorioAttacante=scelta
                
                if(scelta.nome==targetDifensore && scelta.propretario==this.nickNameDifensore)
                this.territorioDifensore=scelta
                
                this.territorioAttacante.confinaCon.forEach(vicino=>{
                    if(vicino==territorioDifensore)
                        //capire come richiamare la battaglia
                    Battaglia.Esegui(territorioAttacante, territorioDifensore, giocatore, 0)
                })
            })

        })
        
        

    }
}

class Battaglia{
    constructor(numeroDadiAttaccante,numeroDadiDifensore,
        numeroArmatePerseAttaccante,numeroArmatePerseDifensore,numeroArmateAttaccante,numeroArmateDifensore){

            this.numeroDadiAttaccante=numeroDadiAttaccante
            this.numeroDadiDifensore=numeroDadiDifensore
            this.numeroArmatePerseAttaccante=numeroArmatePerseAttaccante
            this.numeroArmatePerseDifensore=numeroArmatePerseDifensore
            this.numeroArmateAttaccante=numeroArmateAttaccante
            this.numeroArmateDifensore=numeroArmateDifensore
        }
        static Esegui(territorioAttacante, territorioDifensore, giocatoreAttaccante, i){
        
        let difensore = document.getElementById(`${territorioDifensore.nome}`)  //SISTEMARE MARCELLO... dopo aver finito interfaccia utente
        let attaccante = document.getElementById(`${territorioAttacante.nome}`) //SISTEMARE MARCELLO... dopo aver finito interfaccia utente
        let playerDifensore;

        //ricerca giocatore avversario (capire come inviare array di giocatori)
        numeroGiocatori.forEach(p => {
            if(p.name === territorioDifensore.propretario){
                playerDifensore = p;
            }
        })


        //logica della battaglia:
        while(territorioDifensore.numeroArmate >= 0){
            if(territorioAttacante.numeroArmate == 1){
                attaccante.nextElementSibling.textContent = 1;
                difensore.nextElementSibling.textContent = territorioDifensore.numeroArmate;
                return;
            }
            if("Math.random() > Math.random()"/*usare lancio di dadi SISTEMARE MARCELLO...*/){
                territorioAttacante.numeroArmate -= 1; 
            }
            else{
                territorioDifensore.numeroArmate -= 1;
            }
        }

        if(territorioDifensore.numeroArmate <= 0 ){
            //Remove area from defenders areas array
            numeroGiocatori.forEach(player => {
                if(player.name === territorioDifensore.propretario){
                    let index = player.areas.indexOf(territorioDifensore.name);
                    if (index > -1) {
                        player.areas.splice(index, 1);
                    }
                }
            });
            
            //Swap defender area to attacker and distribute numeroArmate evenly between areas
            territorioDifensore.propretario = giocatoreAttaccante.nome;
            territorioDifensore.colore = giocatoreAttaccante.colore;
            giocatoreAttaccante.areas.push(territorioDifensore.nome);
            difensore.style.fill = territorioDifensore.color;
            difensore.nextElementSibling.textContent = Math.floor(territorioAttacante.numeroArmate / 2);
            territorioDifensore.numeroArmate = Math.floor(territorioAttacante.numeroArmate / 2);
            attaccante.nextElementSibling.textContent = Math.ceil(territorioAttacante.numeroArmate / 2);
            territorioAttacante.numeroArmate = Math.ceil(territorioAttacante.numeroArmate / 2);
            //SISTEMARE MARCELLO...
            //If Defender has no areas left they are eliminated
            if(playerDifensore.areas.length === 0){
                playerDifensore = false;
                let index = numeroGiocatori.indexOf(opp)
                infoName[index].parentElement.classList.add('defeated');
            }
        }
        //se giocatore vince:


        


        /*
        
        Gamestate.battle = function(country, opponent, player, i){
    
            let defender = document.getElementById(`${opponent.name}`)
            let attacker = document.getElementById(`${country.name}`)
            let opp;
            this.players.forEach(p => {
                if(p.name === opponent.owner){
                    opp = p;
                }
            })
            
            //Battle Logic
            while(opponent.numeroArmate >= 0){
                if(country.numeroArmate === 0){
                    attacker.nextElementSibling.textContent = 0;
                    defender.nextElementSibling.textContent = opponent.numeroArmate;
                    return;
                }
                if(Math.random() > Math.random()){
                    country.numeroArmate -= 1; 
                }
                else{
                    opponent.numeroArmate -= 1;
                }
            }
            
            //Handle if Attacker Wins
            if(opponent.numeroArmate <= 0 ){
                //Remove area from defenders areas array
                this.players.forEach(player => {
                    if(player.name === opponent.owner){
                        let index = player.areas.indexOf(opponent.name);
                        if (index > -1) {
                            player.areas.splice(index, 1);
                        }
                    }
                });
                
                //Swap defender area to attacker and distribute numeroArmate evenly between areas
                opponent.owner = player.name;
                opponent.color = player.color;
                player.areas.push(opponent.name);
                defender.style.fill = opponent.color;
                defender.nextElementSibling.textContent = Math.floor(country.numeroArmate / 2);
                opponent.numeroArmate = Math.floor(country.numeroArmate / 2);
                attacker.nextElementSibling.textContent = Math.ceil(country.numeroArmate / 2);
                country.numeroArmate = Math.ceil(country.numeroArmate / 2);
                
                //If Defender has no areas left they are eliminated
                if(opp.areas.length === 0){
                    opp.alive = false;
                    let index = this.players.indexOf(opp)
                    infoName[index].parentElement.classList.add('defeated');
                }
            }
                
            //Calcualting total numeroArmate for each player
            player.numeroArmate = 0;
            opp.numeroArmate = 0;
            this.countries.forEach(c => {
                player.areas.forEach(area => {
                    if(area === c.name){
                        player.numeroArmate += c.numeroArmate
                    }
                })
                opp.areas.forEach(area => {
                    if(area === c.name){
                        opp.numeroArmate += c.numeroArmate
                    }
                })
            })
            
            //Display Bonus modal if player controls continent
            if(this.player.alive){
                continents.forEach(continent => {
                    if(player.areas.containsArray(continent.areas)){   
                        let matchedCountry = continent.areas.some(a => {
                        return a === opponent.name;
                        });
                        if(matchedCountry){
                            bonusModal.style.display = "block";
                            bonusModalPlayer.textContent = player.name + " controls"
                            bonusModalText.textContent = continent.name;
                            bonusModalText.style.color = player.color;
                            bonusModalAmount.textContent = continent.bonus;
                            setTimeout(() => {
                                bonusModal.style.display = "none";
                            }, 2000);
                        }
                    }
                })  
            }
            
            //Win Condition
            if(player.areas.length === 42){
                this.gameOver = true;
                this.win(player);
            }    
        }
 */
        if(player.territoriConquistati.length == 42){
            this.gameOver = true;
            this.win(player);
        }
    }
}